package com.uwan.SSM.AppBeans;

public interface Twocar {
    public void fun4();
}
