package com.uwan.SSM.AppBeans;

public interface Onecar {
    public void f1();
    public void f2();
    public void f3();

}
