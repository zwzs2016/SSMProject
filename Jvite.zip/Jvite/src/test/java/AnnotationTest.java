public class AnnotationTest {
    public void test(){

    }
}
