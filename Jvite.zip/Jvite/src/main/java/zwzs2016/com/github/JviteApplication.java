package zwzs2016.com.github;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import zwzs2016.com.github.AppConfig.BuildConfiguration;
import zwzs2016.com.github.AppConfig.ProjectConfiguration_yml;

@SpringBootApplication
public class JviteApplication {
    public static void main(String[] args) {
        SpringApplication.run(JviteApplication.class,args);
    }
}
