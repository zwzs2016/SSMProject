package zwzs2016.com.github.AppService;

public interface RedisService {
    public String redisconntest();
}
