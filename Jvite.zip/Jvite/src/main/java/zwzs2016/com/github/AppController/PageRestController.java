package zwzs2016.com.github.AppController;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

//@RestController
public class PageRestController {
//    @RequestMapping("/")
//    public String index(){
//        return "<h1>Jvite</h1>";
//    }
}
