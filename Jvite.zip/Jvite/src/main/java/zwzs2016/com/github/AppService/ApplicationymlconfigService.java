package zwzs2016.com.github.AppService;


import org.springframework.stereotype.Service;


public interface ApplicationymlconfigService {
    String jsonfile();
    void setymlinfo(String ymldata);
}
